twurl -t -A "Content-Type: application/json" -d '{"query":"#JoCox","maxResults":"500","fromDate":"201606150500","toDate":"201606152300" }' "/1.1/tweets/search/fullarchive/BrexitMoon.json" > ~/Downloads/sdsv/CASA0006dsss/BrexitMoon/tw/20160615JoCox.json
wurl -t -A "Content-Type: application/json" -d '{"query":"#JoCox","maxResults":"500","fromDate":"201606160500","toDate":"201606162300" }' "/1.1/tweets/search/fullarchive/BrexitMoon.json" > ~/Downloads/sdsv/CASA0006dsss/BrexitMoon/tw/20160616JoCox.json
twurl -t -A "Content-Type: application/json" -d '{"query":"#JoCox","maxResults":"500","fromDate":"201606170500","toDate":"201606172300" }' "/1.1/tweets/search/fullarchive/BrexitMoon.json" > ~/Downloads/sdsv/CASA0006dsss/BrexitMoon/tw/20160617JoCox.json

